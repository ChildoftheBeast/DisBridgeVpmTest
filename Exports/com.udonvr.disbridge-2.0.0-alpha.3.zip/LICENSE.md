Copyright (c) 2021 UdonVR LLC

No Modification of Licensed Software.
Licensee shall not modify, reverse engineer, decompile, disassemble or translate the Licensed Software or related documentation, or apply any other procedure or technology to the Licensed Software so as to determine the source listings for the Licensed Software.

No Open Source.
Software (i) has been modified by the Company or any of its Subsidiaries, (ii) has been embedded in or otherwise combined by the Company or any of its Subsidiaries with any other software or firmware, or (iii) has been distributed by the Company or any of its Subsidiaries to any third party either independently or as part of any product, in each case, in a manner that would condition the license governing such Open Source Software on the Company’s or any of its Subsidiaries’ (A) disclosing or distributing any software or firmware owned by the Company or any of its Subsidiaries in source code form, (B) licensing any software or firmware owned by the Company or any of its Subsidiaries for the purpose of making derivative works or (C) redistributing any software or firmware owned by the Company or any of its Subsidiaries at no or minimal charge.

Plugins created for DisBridge using the included Plugin Template have permission to modify and distribute their plugins.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.