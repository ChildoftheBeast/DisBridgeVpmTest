﻿//Copyright (c) 2021 UdonVR LLC

using System;
using UdonSharp;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;

namespace UdonVR.DisBridge
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class ReadDataManager : UdonSharpBehaviour
    {
        private string outputString;

        [SerializeField] private VRCAvatarPedestal ped;
        [SerializeField] private PluginManager pluginManager;
        [SerializeField] private Base64Reader base64Reader;
        [SerializeField] private GameObject decoder;
        private GameObject tempDecoder;
        //[SerializeField] private Transform aPed;
        [SerializeField] private TMPro.TextMeshProUGUI testText;
        private int version;
        public bool fallbackMode = false;
        private bool emptyUrl = false;

        private void Start()
        {
            emptyUrl = string.IsNullOrWhiteSpace(pluginManager.keyUrl.Get());
        #if UNITY_EDITOR || UNITY_EDITOR_64
            if (emptyUrl)
                fallbackMode = true;
        #endif

            Debug.LogWarning("ReadDataManager Start");
            if(base64Reader == null)
                base64Reader = gameObject.GetComponent<Base64Reader>();
            if (string.IsNullOrEmpty(pluginManager.key) || pluginManager.key == null || pluginManager.key == "")
            {
                fallbackMode = true;
            }
            else if(emptyUrl)
            {
                pluginManager.log("makeId - Start");
                ped.blueprintId = makeId(pluginManager.key);
            }
            pluginManager.Init2();
            DisableInteractive = true;

            if (!fallbackMode)
                SendCustomEventDelayedSeconds(nameof(StartDecoder), 5);
            else ReadIsDone();
        }

        private string makeId(string key)
        {
            return $"avtr_{key.Substring(0, 8)}-{key.Substring(8, 4)}-{key.Substring(12, 4)}-{key.Substring(16, 4)}-{key.Substring(20, 12)}";
        }
        public void StartDecoder()
        {
            if (fallbackMode) return;
            Debug.Log("[UdonVR]Starting Decode");
            DisableInteractive = true;
            if (string.IsNullOrWhiteSpace(pluginManager.keyUrl.Get()))
            {
                if (ped.transform.childCount != 0)
                {
                    Destroy(ped.transform.GetChild(0).gameObject);
                    SendCustomEventDelayedFrames(nameof(StartDecoder), 5);

                    return;
                }
                tempDecoder = Instantiate(decoder);
                tempDecoder.SetActive(true);
            }
            else
            {
                base64Reader.SetKey(pluginManager.key);
                base64Reader.StartDownload(pluginManager.keyUrl);
            }
        }

        public void ReadIsDone()
        {
            //Destroy(tempDecoder);
            DisableInteractive = false;
            Debug.Log("[UdonVR] ReadIsDone");
            //Debug.Log("[UdonVR] Output ["+outputString+"]");
            if (fallbackMode || version >= 1000)
            {
                pluginManager.logWarning("Using fallback");
                Fallback();
            }
            else if (version == 2)
                ParseSupportersV2(outputString);
            else
            {
                string[] modules = outputString.Split('|');
                for (int i = 0; i < modules.Length; i++)
                {
                    string[] modData = modules[i].Split(';');
                    if (modData.Length != 2)
                        continue;
                    if (modData[0] == "sl")
                        ParseSupporters(modData[1]);
                }
            }
        }

        private void Fallback()
        {
            Debug.LogWarning(nameof(Fallback));
            fallbackMode = true;
            foreach (var _role in pluginManager.roles.GetComponentsInChildren<RoleContainer>())
            {
                _role._Init(new string[0]);
            }
            SendCustomEventDelayedFrames(nameof(_FallbackEnd),0);
        }

        public void _FallbackEnd()
        {
            pluginManager.Init();
        }
        private void ParseSupporters(string suppString)
        {
            Debug.Log("[UdonVR] Start ParseSupporters");
            //Debug.Log("[UdonVR] Output [" + outputString + "]");
            if (string.IsNullOrWhiteSpace(suppString) || fallbackMode)
            {
                pluginManager.logWarning("ParseSupporters is null, using fallback");
                Fallback();
                return;
            }

            var roles = suppString.Split('\n');
            Debug.Log("[UdonVR] roles " + roles.Length);
            for (int i = 0; i < roles.Length; i++)
            {
                Debug.Log($"[UdonVR] roles[{i}]-> [{roles[i]}]");
                var roleSupporters = roles[i].Split(',');
                Debug.Log("[UdonVR] roleSupporters " + roleSupporters.Length);
                if (roleSupporters.Length == 2)
                {
                    RoleContainer _tmp = null;
                    if (roleSupporters[0].Length < 3)
                        _tmp = pluginManager.GetRole(i);
                    else
                    {
                        //pluginManager.log($"getting role [{roleSupporters[0]}]");
                        _tmp = pluginManager.GetRoleById(roleSupporters[0]);
                    }
                    if (_tmp != null)
                    {
                        var vrcNames = roleSupporters[1].Split('.');
                        Debug.Log("[UdonVR] vrcNames " + vrcNames.Length);
                        _tmp._Init(vrcNames);
                        Debug.Log("[UdonVR] Inited RoleContainer " + _tmp.roleName);
                    }
                    else
                        Debug.LogError("[UdonVR] Got NULL RoleContainer index: " + i);
                }
            }
            pluginManager.Init();
        }
        private void ParseSupportersV2(string suppString)
        {
            Debug.Log("[UdonVR] Start ParseSupporters");
            //Debug.Log("[UdonVR] Output [" + outputString + "]");
            if (string.IsNullOrWhiteSpace(suppString) || fallbackMode)
            {
                pluginManager.logWarning("ParseSupporters is null, using fallback");
                Fallback();
                return;
            }

            var roles = suppString.Split('\n');
            Debug.Log("[UdonVR] roles " + roles.Length);
            for (int i = 0; i < roles.Length; i++)
            {
                Debug.Log($"[UdonVR] roles[{i}]-> [{roles[i]}]");
                var roleSupporters = roles[i].Split(',');
                Debug.Log("[UdonVR] roleSupporters " + roleSupporters.Length);
                if (roleSupporters.Length == 4)
                {
                    var vrcNames = roleSupporters[2].Split('.');
                    Debug.Log("[UdonVR] vrcNames " + vrcNames.Length);
                    RoleContainer _tmp = pluginManager.GetRole(i);
                    if (_tmp != null)
                    {
                        _tmp._Init(vrcNames);
                        Debug.Log("[UdonVR] Inited RoleContainer " + _tmp.roleName);
                    }
                    else
                        Debug.LogError("[UdonVR] Got NULL RoleContainer index: " + i);
                }
            }
            pluginManager.Init();
        }

        public void _ReadDone(string key, string currentOutputString)
        {
            Debug.Log("[UdonVR] _ReadDone ["+key+"]");
            if (version > 3)
            {
                outputString = currentOutputString;
                ReadIsDone();
                return;
            }

            Destroy(tempDecoder);
            outputString += currentOutputString;
            if (testText)
                testText.text = outputString;
            if (key.StartsWith( "fffff"))
            {
                Debug.Log("[UdonVR] _ReadDone no next key");
                ReadIsDone();
            }
            //ffffffffffffffffffffffffffffffff
﻿            //ffffffffffffffffffffffffffffffff
            else
            {
                if (fallbackMode) return;
                pluginManager.log("makeId - Read Done");
                string avaId = makeId(key);
                //Debug.Log("[UdonVR] _ReadDone has next key " + avaId);
                ped.blueprintId = avaId;
                SendCustomEventDelayedFrames(nameof(StartDecoder), 5);
            }
        }

        public void PassVersion(int _version)
        {
            if (_version >= 50000)
            {
                fallbackMode = true;
                Fallback();
            }
            version = _version;
            pluginManager.CheckVersion(_version);
        }
    }
}