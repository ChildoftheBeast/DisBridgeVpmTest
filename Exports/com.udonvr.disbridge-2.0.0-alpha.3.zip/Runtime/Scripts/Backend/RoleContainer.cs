﻿//Copyright (c) 2021 UdonVR LLC

using System;
using System.Linq;
using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;
using VRC.Udon;

namespace UdonVR.DisBridge
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class RoleContainer : UdonSharpBehaviour
    {
        [Tooltip("The Id of the Role.")]
        [SerializeField]
        public string roleId;
        [Tooltip("The name of the Role itself.\nexample: Moderators")]
        [SerializeField]
        public string roleName;
        [Tooltip("The name used to identify a single member of the role.\nexample: Moderator")]
        [SerializeField]
        public string roleAltName;

        public Sprite roleIcon;
        public Color32 roleColor = new Color32(52,152,219,255);
        private bool hasInit = false;

        [Tooltip(
            "This allows you do add people manually to roles.\n\nAdd their VRChat username to this list\nCasE SeNSitiVE.")]
        [SerializeField]
        private string[] manualMembers;
        
        private string[] members;
        [SerializeField] private bool isStaff = false;
        [SerializeField] private bool isSupporter = true;

        [Tooltip(
            "You can only have 1 role marked as the Booster role. if you have more than one, the first one will be used as the booster role.")]
        public bool isBooster = false;
        
        
        /// <summary>
        /// Internal method for initialization. This shouldn't be ran by the end user.
        /// </summary>
        public void _Init(string[] _rawMembers)
        {
            if (hasInit) return;
            hasInit = true;

            if (DisBridgeFunctions.IsArrayNullOrEmpty(_rawMembers))
            {
                members = manualMembers;
                return;
            }

            members = new string[manualMembers.Length + _rawMembers.Length];
            Array.Copy(_rawMembers,members,_rawMembers.Length);
            int i = _rawMembers.Length;
            int emptySlots = 0;
            foreach (var _member in manualMembers)
            {
                if (Array.IndexOf(members, _member) == -1)
                {
                    members[i] = _member;
                    i++;
                }
                else
                {
                    emptySlots++;
                }
            }

            if (emptySlots > 0)
            {
                Array.Copy(members,members,(members.Length - emptySlots));
            }
        }

        /// <summary>
        /// Returns a string array with all the members in this role.
        /// </summary>
        /// <returns><b>String[]</b> – Array of player display names</returns>
        public string[] GetMembers()
        {
            return members;
        }

        /// <summary>
        /// Adds the members to bottom of the target string array and returns the merged string array.
        /// </summary>
        /// <param name="_array">Array you want to add members to.</param>
        /// <returns><b>String[]</b> – Merged array of player display names.</returns>
        public string[] AddMembersToArray(string[] _array)
        {
            string[] _tmpArray;
            if (_array == null || _array.Length == 0)
            {
               return members;
            }
            else
            {
                _tmpArray = new string[_array.Length + members.Length];
                int i = 0;
                foreach (var _name in _array)
                {
                    _tmpArray[i] = _name;
                    i++;
                }

                foreach (var _name in members)
                {
                    _tmpArray[i] = _name;
                    i++;
                }
            }

            return _tmpArray;
        }

        /// <summary>
        /// Returns how many members are in the role.
        /// </summary>
        /// <returns><b>int</b> – number of members</returns>
        public int GetMemberCount()
        {
            if (members == null) return 0;
            return members.Length;
        }

        /// <summary>
        /// Used to check if the player is a member of this role.
        /// </summary>
        /// <param name="_player"> The player you're wanting to check.</param>
        /// <returns><b>bool</b> – True/False</returns>
        public bool IsMember(VRCPlayerApi _player)
        {
            string _name = _player.displayName;
            foreach (var _member in members)
            {
                if (_name == _member)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// returns if the role is a Staff role.
        /// </summary>
        /// <returns><b>bool</b> – True/False</returns>
        public bool IsRoleStaff()
        {
            return isStaff;
        }

        /// <summary>
        /// returns if the role is your Booster role.
        /// <br></br><b>!!YOU CAN ONLY HAVE ONE OF THESE!!</b>
        /// </summary>
        /// <returns><b>bool</b> – True/False</returns>
        public bool IsRoleBooster()
        {
            return isBooster;
        }

        /// <summary>
        /// returns if the role is a Supporter role.
        /// </summary>
        /// <returns><b>bool</b> – True/False</returns>
        public bool IsRoleSupporter()
        {
            return isSupporter;
        }

#if UNITY_EDITOR
        /// <summary>
        /// Returs a string array with ONLY the manual members added at editor time.
        /// </summary>
        /// <returns><b>String[]</b> – Array of player display names manually added by the user (Editor Only)</returns>
        public string[] GetManuals()
        {
            return manualMembers;
        }

        /// <summary>
        /// Sets the IsStaff bool
        /// </summary>

        public void SetStaff(bool tf)
        {
            isStaff = tf;
        }

        /// <summary>
        /// Sets the isSupporter bool
        /// </summary>

        public void SetisSupporter(bool tf)
        {
            isSupporter = tf;
        }

        /// <summary>
        /// Initialize string array with a int value of x
        /// </summary>

        public void SetManual(int x)
        {
            manualMembers = new string[x];
        }

        /// <summary>
        /// Sets the value of manualMembers[i] with a string input;
        /// </summary>

        public void SetManualMember(int i, string input)
        {
            manualMembers[i] = input;
        }
    #endif
    }
}
