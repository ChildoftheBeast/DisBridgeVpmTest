﻿//Copyright (c) 2021 UdonVR LLC

using System;
using TMPro;
using UdonSharp;
using UdonVR.DisBridge.Plugins;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

namespace UdonVR.DisBridge
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class PluginManager : UdonSharpBehaviour
    {
        [Header("Key")]
        [Tooltip("Your key can be found by running `/guild-status` as an admin.")]
        public string key;
        public VRCUrl keyUrl;

        [Header("Roles")]
        [Tooltip("This should be the parent object for your Role Containers.")]
        public Transform roles;
        private RoleContainer[] _roles;
        private string[] _roleIds;

        [HideInInspector] public DisBridgeDebugger debugger;
        [HideInInspector] public bool hasDebugger = false;
        private string debuggerLog;
        
        
        private GameObject[] plugins;


        //un serialize these
        [Header("Backend")]
        private string[] supporters;
        private string[] staff;
        private string[] boosters;
        private RoleContainer boosterRole;
        private RoleContainer[] supporterRoles;
        private RoleContainer[] staffRoles;
        private bool hasInit = false;
        private bool hasPluginInit = false;
        private int version = 4;

        private bool Init2Ran = false;

        private bool isLocalStaff = false;
        private bool isLocalSupporter = false;
        private bool isLocalBooster = false;

        private UdonBehaviour _tmp_UdonBehaviour;
        private string _tmp_String;
        

        #region Is[X]

        /// <summary>
        /// Checks to see if the target player is a member of the specified role.
        /// </summary>
        /// <param name="_role">The index of the role you want to check for.</param>
        /// <param name="_player">The VRCPlayerAPI of the player you want to check.</param>
        /// <returns><b>bool</b> – True/False</returns>
        public bool IsMember(int _role,VRCPlayerApi _player)
        {
            if (!HasInit()) return false;
            if (hasDebugger)
            {
                if (debugger.roleOverrideCheck(_role)) return true;
            }
            return _roles[_role].IsMember(_player);
        }
        
        /// <summary>
        /// Checks to see if the local player is a Supporter
        /// </summary>
        /// <returns><b>bool</b> – True/False</returns>
        public bool IsSupporter()
        {
            return isLocalSupporter;
        }
        
        /// <summary>
        /// Checks to see if the target player is a Supporter
        /// </summary>
        /// <param name="_player">The VRCPlayerAPI of the player you want to check.</param>
        /// <returns><b>bool</b> – True/False</returns>
        public bool IsSupporter(VRCPlayerApi _player)
        {
            if (!HasInit())
            {
                logError("Plugin Manager has not Initialized.");
                return false;
            }
            if (IsSupporter()) return true;
            
            if (supporters == null)
            {
                logWarning("Supporter array is Null, returning staff check as false!");
                return false;
            }
            if (supporters.Length == 0)
            {
                logWarning("Supporter array is Empty, returning staff check as false!");
                return false;
            }
            string _name = _player.displayName;
            foreach (var _supporter in supporters)
            {
                if (_supporter == _name)
                {
                    return true;
                }
            }
            if (hasDebugger) return debugger.supporterOverride;
            return false;
        }

        /// <summary>
        /// Checks to see if the local player is a Staff member
        /// </summary>
        /// <returns><b>bool</b> – True/False</returns>
        public bool IsStaff()
        {
            return isLocalStaff;
        }
        
        /// <summary>
        /// Checks to see if the target player is a Staff member
        /// </summary>
        /// <param name="_player">The VRCPlayerAPI of the player you want to check.</param>
        /// <returns><b>bool</b> – True/False</returns>
        public bool IsStaff(VRCPlayerApi _player)
        {
            if (!HasInit())
            {
                logError("Plugin Manager has not Initialized.");
                return false;
            }
            if (IsStaff()) return true;
            
            if (staff == null)
            {
                logWarning("Staff array is Null, returning staff check as false!");
                return false;
            }
            if (staff.Length == 0)
            {
                logWarning("Staff array is Empty, returning staff check as false!");
                return false;
            }
            string _name = _player.displayName;
            foreach (var _supporter in staff)
            {
                if (_supporter == _name)
                {
                    return true;
                }
            }
            if (hasDebugger) return debugger.staffOverride;
            return false;
        }

        /// <summary>
        /// Checks to see if the local player is a Server Booster
        /// </summary>
        /// <returns><b>bool</b> – True/False</returns>
        public bool IsBooster()
        {
            return isLocalBooster;
        }
        
        /// <summary>
        /// Checks to see if the target player is a Server Booster
        /// </summary>
        /// <param name="_player"></param>
        /// <returns><b>bool</b> – True/False</returns>
        public bool IsBooster(VRCPlayerApi _player)
        {
            if (!HasInit())
            {
                logError("Plugin Manager has not Initialized.");
                return false;
            }
            if (IsBooster()) return true;
            
            if (boosters == null)
            {
                logWarning("boosters array is Null, returning staff check as false!");
                return false;
            }
            if (boosters.Length == 0)
            {
                logWarning("boosters array is Empty, returning staff check as false!");
                return false;
            }
            string _name = _player.displayName;
            foreach (var _supporter in boosters)
            {
                if (_supporter == _name)
                {
                    return true;
                }
            }
            return false;
        }
        
        #endregion

        #region Get[X]

        /// <summary>
        /// Returns a string array of player display names based of the selected Index.
        /// </summary>
        /// <param name="_role">The index of the role you want to check for.</param>
        /// <returns><b>String[]</b> – Array of player display names.</returns>
        public string[] GetRoleDisplaynames(int _role)
        {
            if (!HasInit()) return null;
            return _roles[_role].GetMembers();
        }

        /// <summary>
        /// Returns a string array with all of your supporter's display names.
        /// </summary>
        /// <returns><b>String[]</b> – List of ALL supporter display names</returns>
        public string[] GetSupporterDisplaynames()
        {
            if (!HasInit()) return null;
            return supporters;
        }

        /// <summary>
        /// Returns a string array with all of your staff's display names.
        /// </summary>
        /// <returns><b>String[]</b> – List of ALL staff diaplay names</returns>
        public string[] GetStaffDisplaynames()
        {
            if (!HasInit()) return null;
            return staff;
        }
        
        /// <summary>
        /// Returns a string array of player Display Names.
        /// </summary>
        /// <returns><b>String[]</b> – List of player Display Names</returns>
        public string[] GetBoosterDisplaynames()
        {
            if (!HasInit()) return null;
            return boosters;
        }
        
        /// <summary>
        /// Returns a list of player display names based of the selected Index.
        /// </summary>
        /// <param name="_role">The index of the role you want to check for.</param>
        /// <returns><b>String[]</b> – Array of player display names.</returns>
        public RoleContainer GetRole(int _role)
        {
            if (_role >= _roles.Length) return null;
            //if (!HasInit()) return null;
            return _roles[_role];
        }

        /// <summary>
        /// Returns a list of player display names based of the selected Index.
        /// </summary>
        /// <param name="_role">The index of the role you want to check for.</param>
        /// <returns><b>String[]</b> – Array of player display names.</returns>
        public RoleContainer GetRoleById(string _roleId)
        {
            var i = Array.IndexOf(_roleIds, _roleId);
            //log($"[UdonVR]GetRoleById({_roleId}) = {i}");
            if(i == -1) return null;
            return GetRole(i);
        }

        /// <summary>
        /// Returns a list of all the Role Containers.
        /// </summary>
        /// <returns><b>RoleContainer[]</b> – Array of RoleContainers</returns>
        public RoleContainer[] GetRoles()
        {
            //if (!HasInit()) return null;
            return _roles;
        }
        
        #endregion

        /// <summary>
        /// Internal use only.
        /// </summary>
        public void Init()
        {
            BuildStaffAndSupporterArrays();
            BuildBoosterRole();
            
            hasInit = true;

            isLocalStaff = IsStaff(Networking.LocalPlayer);
            isLocalSupporter = IsSupporter(Networking.LocalPlayer);
            isLocalBooster = IsBooster(Networking.LocalPlayer);

            InitPlugins();
        }

        /// <summary>
        /// Internal use only.
        /// </summary>
        public void Init2()
        {
            if (Init2Ran) return;
            _roles = roles.GetComponentsInChildren<RoleContainer>();
            InitRoleIds();
            Init2Ran = true;
        }
        /// <summary>
        /// Internal use only.
        /// </summary>
        public void InitRoleIds()
        {
            _roleIds = new string[_roles.Length];
            for(int i = 0; i< _roles.Length; i++)
            {
                _roleIds[i] = _roles[i].roleId;
                log($"rID[{i}]({_roles[i].name}) = ({_roles[i].roleId})");
            }
        }

        /// <summary>
        /// Registers your plugin into the PluginManager for Initialization. Should be used with the local GameObject `gameObject`.
        /// </summary>
        /// <param name="_plugin">This should be the GameObject that your script is attached to. this is just `gameObject` in most cases.</param>
        public void AddPlugin(GameObject _plugin)
        {
            plugins = DisBridgeFunctions.AddToArray(_plugin, plugins);
            if (hasPluginInit)
            {
                _tmp_UdonBehaviour = plugins[plugins.Length -1].GetComponent<UdonBehaviour>();
                _tmp_UdonBehaviour.SendCustomEvent("_UVR_Init");
                _tmp_String = $"{_tmp_String}\n[{plugins.Length -1}]{_tmp_UdonBehaviour.gameObject.name}";
                if (hasDebugger) debugger.LoadPlugins(_tmp_String,plugins);
            }
        }


        private bool debugColor = false;
        private string debugColor1 = "#FFFFFF";
        private string debugColor2 = "#cccccc";
        /// <summary>
        /// Prints a debug log to the Console and to the Debugger if attached to the PluginManager.
        /// </summary>
        /// <param name="_log">The log you want printed</param>
        public void log(string _log)
        {
            Debug.Log($"[UdonVR][DisBridge]{_log}");
            if (hasDebugger)
            {
                debuggerLog = ($"{debuggerLog}\n<{(debugColor ? debugColor1 : debugColor2)}>{_log}");
                debugger.log(debuggerLog);
                debugColor = !debugColor;
            }
        }
        /// <summary>
        /// Prints a debug log Warning to the Console and to the Debugger if attached to the PluginManager.
        /// </summary>
        /// <param name="_log">The log you want printed</param>
        public void logWarning(string _log)
        {
            Debug.LogWarning($"[UdonVR][DisBridge]!! {_log}");
            if (hasDebugger)
            {
                debuggerLog = ($"{debuggerLog}\n<{(debugColor ? debugColor1 : debugColor2)}>{_log}");
                debugger.log(debuggerLog);
                debugColor = !debugColor;
            }
        }
        /// <summary>
        /// Prints a debug log Error to the Console and to the Debugger if attached to the PluginManager.
        /// </summary>
        /// <param name="_log">The log you want printed</param>
        public void logError(string _log)
        {
            Debug.LogError($"[UdonVR][DisBridge]!!ERROR!! {_log}");
            if (hasDebugger)
            {
                debuggerLog = ($"{debuggerLog}\n<{(debugColor ? debugColor1 : debugColor2)}>{_log}");
                debugger.log(debuggerLog);
                debugColor = !debugColor;
            }
        }

        public bool HasInit()
        {
            return hasInit;
        }

        
        private void InitPlugins()
        {
            log("Starting plugin initialization");

            if (plugins.Length == 0)
            {
                hasPluginInit = true;
                return;
            }
            
            _tmp_String = "";
            for (int i = 0; i < plugins.Length; i++)
            {
                _tmp_UdonBehaviour = plugins[i].GetComponent<UdonBehaviour>();
                _tmp_UdonBehaviour.SendCustomEvent("_UVR_Init");
                _tmp_String = $"{_tmp_String}\n[{i}]{_tmp_UdonBehaviour.gameObject.name}";
            }
            if (hasDebugger) debugger.LoadPlugins(_tmp_String,plugins);
            hasPluginInit = true;
        }

        public void CheckVersion(int _version)
        {
            if (_version == version) return;
            
            logError("Version mismatch detected!!\nPlugins might not function because of this, please update DisBridge.");
            logError($"Version {version} expected, received version {_version}");
            UdonBehaviour _tmp;
            foreach (var _plugin in plugins)
            {
                _tmp = (UdonBehaviour)_plugin.GetComponent(typeof(UdonBehaviour));
                _tmp.SendCustomEvent("_UVR_VersionMismatch");
            }
        }
        
        private void BuildBoosterRole()
        {
            foreach (var _role in _roles)
            {
                if (_role.IsRoleBooster())
                {
                    log($"setting {_role.name} as boosterRole");
                    boosterRole = _role;
                    break;
                }
            }
            if (boosterRole != null)
            {
                boosters = boosterRole.GetMembers();
            }
            else
            {
                logWarning("Booster Role is null!");
                boosters = new string[1] {""};
            }
        }
        private void BuildStaffAndSupporterArrays()
        {
            log("Building Staff and Supporter Arrays");
            foreach (var _role in _roles)
            {
                if (_role.IsRoleSupporter())
                {
                    log($"adding {_role} to supporterRoles array");
                    supporterRoles = DisBridgeFunctions.AddToArray(_role, supporterRoles);
                }

                if (_role.IsRoleStaff())
                {
                    log($"adding {_role} to staffRoles array");
                    staffRoles = DisBridgeFunctions.AddToArray(_role, staffRoles);
                }
            }

            if (supporterRoles != null)
            {
                foreach (var role in supporterRoles)
                {
                    log($"Adding {role.name} to supporters");
                    supporters = role.AddMembersToArray(supporters);
                }
            }
            else
            {
                logWarning("Supporter Roles are null!");
                supporters = new string[1] {""};
            }

            if (staffRoles != null)
            {
                foreach (var role in staffRoles)
                {
                    log($"Adding {role.name} to staff");
                    staff = role.AddMembersToArray(staff);
                }
            }
            else
            {
                logWarning("Staff Roles are null!");
                staff = new string[1] {""};
            }
        }
    }
}