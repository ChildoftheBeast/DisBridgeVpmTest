﻿using Newtonsoft.Json;
using UnityEngine;

public class RoleModal
{
    public string roleId;
    public string roleName;
    public string roleColor;
    public bool isBooster;

    public Color32 GetColor()
    {
        ColorUtility.TryParseHtmlString(roleColor, out Color color);
        return color;
    }
}

public class DisbridgeKey
{
    public string key;
    public string keyUrl;
    public RoleModal[] roles;

}
