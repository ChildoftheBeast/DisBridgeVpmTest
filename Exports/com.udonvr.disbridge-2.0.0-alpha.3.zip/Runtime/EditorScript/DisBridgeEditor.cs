﻿#if UNITY_EDITOR
using Newtonsoft.Json;
using System;
using UdonVR.DisBridge;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using Button = UnityEngine.UIElements.Button;
using File = System.IO.File;
using Toggle = UnityEngine.UIElements.Toggle;

public class DisBridgeEditor : MonoBehaviour 
{

} //Literally just here to attach to a Game Object

[CustomEditor(typeof(DisBridgeEditor))]
public class DisbridgeInspector : Editor
{
    #region Variables
    private DisBridgeEditor EditorFunctions; //Used to manipulate children.
    private VisualElement _RootElement;
    private VisualTreeAsset _VisualTree;

    private RoleContainer[] roles; //Derived from u#
    private Foldout[] RoleContainers; //All the role reps stored in an array to shorten search times.

    private ListView LV;
    private VisualElement ucc;

    private int RcCount;
    private GameObject RoleContainerPrefab;
    private Transform RolesTransform;

    private PluginManager pm;

    private int currentFoldout = -1;

    //ui elements
    Button incButton;
    Button decButton;
    Button ParseButton; 
    Button QuestionMarkButton;

    private static string _folderpath = "Packages/com.udonvr.disbridge";
    #endregion

    #region Init
    public void OnEnable()
    {
        Undo.undoRedoPerformed += MyUndo;
        EditorFunctions = (DisBridgeEditor)target;
        pm = FindObjectOfType<PluginManager>();
        _RootElement = new VisualElement();
        _RootElement.style.minWidth = 400;

        _VisualTree = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>($"{_folderpath}/Runtime/EditorScript/DisbridgeTemplate.uxml");
        StyleSheet style = AssetDatabase.LoadAssetAtPath<StyleSheet>($"{_folderpath}/Runtime/EditorScript/DisbridgeStyle.uss");

        RoleContainerPrefab = AssetDatabase.LoadAssetAtPath<GameObject>($"{_folderpath}/Runtime/Prefabs/Parts/RoleContainer.prefab");

        _RootElement.styleSheets.Add(style);

        //Debug.Log($"{Screen.width} x {Screen.height}");
        
        if (PrefabUtility.IsPartOfAnyPrefab(EditorFunctions.gameObject))
        {
            PrefabUtility.UnpackPrefabInstance(EditorFunctions.gameObject,PrefabUnpackMode.OutermostRoot,InteractionMode.AutomatedAction);
        }
        if (PrefabUtility.IsPartOfAnyPrefab(pm.gameObject))
        {
            PrefabUtility.UnpackPrefabInstance(pm.gameObject,PrefabUnpackMode.OutermostRoot,InteractionMode.AutomatedAction);
        }
    }

    private void MyUndo()
    {
        CreateInspectorGUI();
    }

    public override VisualElement CreateInspectorGUI() //This is where we establish the visual elements. If you want to add more buttons just preform a q. and assign it a function.
    {
        _RootElement.Clear();
        _VisualTree.CloneTree(_RootElement);

        incButton = _RootElement.Q<Button>("IncButton");
        incButton.clicked += IncButton_clicked;

        decButton = _RootElement.Q<Button>("DecButton");
        decButton.clicked += DecButton_clicked;

        ParseButton = _RootElement.Q<Button>("ParseButton");
        ParseButton.clicked += ParseButton_clicked;

        QuestionMarkButton = _RootElement.Q<Button>("QuestionMarkButtton");
        QuestionMarkButton.clicked += QuestionMarkButton_clicked;

        LV = _RootElement.Q<ListView>("RoleContainer");
        ucc = LV.Q<VisualElement>("unity-content-container");

        EstablishFoldOuts();

        CheckBooters();
        return _RootElement;
    }

    private void EstablishFoldOuts() //Counts the roles from the game object and generates custom foldouts to represent them.
    {
        
        RolesTransform = pm.roles;
        roles = RolesTransform.GetComponentsInChildren<RoleContainer>();

        RoleContainers = new Foldout[roles.Length];
        for (int i = 0; i < roles.Length; i++)
        {
            ucc.Add(BuildFoldout(roles[i], i));
        }

    }

    private VisualElement BuildFoldout(RoleContainer role, int id)
    {
        roles[id].gameObject.name = role.roleName;

        VisualElement ve = new VisualElement();
        ve.name = $"VisualElementRC_{id}";
        ve.style.flexDirection = FlexDirection.Row;
        ve.style.justifyContent = Justify.SpaceBetween;
        ve.style.alignItems = Align.Center;
        ve.style.paddingBottom = 5;
        ve.style.paddingTop = 5;
        ve.style.paddingRight = 0;
        ve.style.paddingLeft = 15;



        if (id % 2 == 0)
        {
            Color c = new Color32(0, 0, 0, 50);
            ve.style.backgroundColor = c;
        }

        ve.style.marginTop = .5f;
        ve.style.marginBottom = .5f;
        //ve.style.marginLeft = 5;
        //ve.style.marginRight = 5;

        Foldout ContentFoldout = new Foldout();
        ContentFoldout.text = "   " + role.roleName;
        ContentFoldout.style.paddingLeft = 10f;
        ContentFoldout.name = $"RoleContainerFoldout_{id}";
        ContentFoldout.value = false;

        Color32 c32 = roles[id].roleColor;
        StyleColor sc = new StyleColor(c32);

        ve.style.borderRightWidth = 1;
        ve.style.borderBottomWidth = 1;
        ve.style.borderLeftWidth = 1;
        ve.style.borderTopWidth = 1;
        //ve.style.borderColor = sc;
        ve.style.borderBottomColor = sc;
        ve.style.borderLeftColor = sc;
        ve.style.borderRightColor = sc;
        ve.style.borderTopColor = sc;

        ve.style.borderBottomLeftRadius = 5;
        ve.style.borderBottomRightRadius = 5;
        ve.style.borderTopLeftRadius = 5;
        ve.style.borderTopRightRadius = 5;

        TextField roleId = new TextField();
        roleId.label = "Role Id";
        roleId.name = $"roleIdField_{id}";
        roleId.SetValueWithoutNotify(role.roleId);
        roleId.RegisterCallback<FocusOutEvent, int>(IdFieldEdit, id, TrickleDown.NoTrickleDown);

        TextField roleName = new TextField();
        roleName.label = "Role Name";
        roleName.name = $"roleNameField_{id}";
        roleName.SetValueWithoutNotify(role.roleName);
        roleName.RegisterCallback<FocusOutEvent, int>(FieldEdit, id, TrickleDown.NoTrickleDown);

        TextField RoleAltName = new TextField();
        RoleAltName.name = $"RoleAltNameField_{id}";
        RoleAltName.label = "Alternitave Role Name";
        RoleAltName.SetValueWithoutNotify(role.roleAltName);
        RoleAltName.RegisterCallback<FocusOutEvent, int>(FieldEdit, id, TrickleDown.NoTrickleDown);

        ObjectField Icon = new ObjectField();
        Icon.name = $"RoleIconField_{id}_";
        Icon.objectType = typeof(Sprite);
        Icon.label = "Role Icon";
        Icon.RegisterValueChangedCallback(IconEdit);

        ColorField colorField = new ColorField();
        colorField.name = $"RoleColorField_{id}_";
        colorField.label = "Role Color";
        colorField.value = role.roleColor;
        colorField.RegisterValueChangedCallback(ColorEdit);

        //Manual Fold
        string[] getManuals = role.GetManuals();
        
        Foldout ManualFold = new Foldout();
        ManualFold.name = $"ManualFoldout_{id}";
        ManualFold.text = $"Manual Usernames: {getManuals.Length}";
        ManualFold.value = false;

        VisualElement manualContainer = new VisualElement();


        IntegerField Count = new IntegerField();
        Count.name = $"ManualFoldoutCount_{id}_";
        Count.label = "User name count";
        Count.SetValueWithoutNotify(role.GetManuals().Length);
        Count.RegisterValueChangedCallback((evt) => IntFieldEdited(evt, manualContainer));

        Label TypeOfRole = new Label();
        TypeOfRole.text = "Type of role";
        TypeOfRole.style.paddingTop = 5;

        Toggle IsStaff = new Toggle();
        IsStaff.name = $"IsStaff_{id}_";
        IsStaff.value = role.IsRoleStaff();
        IsStaff.label = "Is Staff?";
        IsStaff.RegisterValueChangedCallback(ToggleEdit);

        Toggle IsSupporter = new Toggle();
        IsSupporter.name = $"IsSupporter_{id}_";
        IsSupporter.value = role.IsRoleSupporter();
        IsSupporter.label = "Is Supporter?";
        IsSupporter.RegisterValueChangedCallback(ToggleEdit);

        Toggle IsBooster = new Toggle();
        IsBooster.name = $"IsBooster_{id}_";
        IsBooster.value = role.IsRoleBooster();
        IsBooster.label = "Is Booster?";
        IsBooster.RegisterValueChangedCallback(ToggleEdit);
        IsBooster.style.paddingBottom = 10;

        Button DeleteButton = new Button();
        DeleteButton.name = $"RoleDeleteButton_{id}";
        DeleteButton.clickable.clicked += () => DeleteButton_clicked(id);
        DeleteButton.style.color = Color.black;
        DeleteButton.style.backgroundColor = Color.red;
        DeleteButton.style.alignSelf = Align.FlexEnd;
        DeleteButton.style.width = 75;
        DeleteButton.text = "Delete Role";


        ManualFold.Add(Count);
        ManualFold.Add(manualContainer);
        
        for (int i = 0; i < Count.value; i++)
        {
            TextField FieldOut = new TextField();
            FieldOut.label = manualContainer.childCount.ToString();
            FieldOut.name = $"ManualField_{id}_{i}";
            FieldOut.value = getManuals[i];
            FieldOut.RegisterCallback<FocusOutEvent, string>(ManualFieldEdit, FieldOut.name, TrickleDown.NoTrickleDown);

            manualContainer.Add(FieldOut);
        }
        ContentFoldout.Add(roleId);
        ContentFoldout.Add(roleName);
        ContentFoldout.Add(RoleAltName);
        ContentFoldout.Add(Icon);
        ContentFoldout.Add(colorField);
        ContentFoldout.Add(ManualFold);
        ContentFoldout.Add(TypeOfRole);
        ContentFoldout.Add(IsStaff);
        ContentFoldout.Add(IsSupporter);
        ContentFoldout.Add(IsBooster);
        ContentFoldout.Add(DeleteButton);

        RcCount++;
        RoleContainers[id] = ContentFoldout;

        ve.Add(ContentFoldout);

        VisualElement veMoveButtons = new VisualElement();
        
        veMoveButtons.style.flexDirection = FlexDirection.Row;
        veMoveButtons.style.justifyContent = Justify.Center;
        veMoveButtons.style.alignItems = Align.Center;
        veMoveButtons.style.paddingBottom = 5;
        veMoveButtons.style.paddingTop = 5;
        veMoveButtons.style.paddingRight = 0;
        veMoveButtons.style.paddingLeft = 15;
        
        ve.Add(veMoveButtons);
        if (id != 0)
        {
            Button MoveButtonUp = new Button();
            MoveButtonUp.text = "Up";
            MoveButtonUp.style.height = 15;
            MoveButtonUp.clickable.clicked += () => MoveRoleUp(id);
            
            MoveButtonUp.style.justifyContent = Justify.Center;
            //MoveButtonUp.style.alignItems = Align.FlexEnd;
            //MoveButtonUp.style.alignSelf = Align.FlexEnd;
            //MoveButtonUp.style.alignContent = Align.FlexEnd;
            
            veMoveButtons.Add(MoveButtonUp);
        }
        else
        {
            Button MoveButtonUp = new Button();
            MoveButtonUp.text = "Up";
            MoveButtonUp.style.height = 15;
            MoveButtonUp.SetEnabled(false);
            
            MoveButtonUp.style.justifyContent = Justify.Center;
            //MoveButtonUp.style.alignItems = Align.FlexEnd;
            //MoveButtonUp.style.alignSelf = Align.FlexEnd;
            //MoveButtonUp.style.alignContent = Align.FlexEnd;
            
            veMoveButtons.Add(MoveButtonUp);
        }
        if (id != RoleContainers.Length - 1)
        {
            Button MoveButtonDown = new Button();
            MoveButtonDown.text = "Down";
            MoveButtonDown.style.height = 15;
            MoveButtonDown.clickable.clicked += () => MoveRoleDown(id);
            
            MoveButtonDown.style.justifyContent = Justify.Center;
            //MoveButtonDown.style.alignItems = Align.FlexEnd;
            // MoveButtonDown.style.alignSelf = Align.FlexEnd;
            
            veMoveButtons.Add(MoveButtonDown);
        }
        else
        {
            Button MoveButtonDown = new Button();
            MoveButtonDown.text = "Down";
            MoveButtonDown.style.height = 15;
            MoveButtonDown.SetEnabled(false);
            
            MoveButtonDown.style.justifyContent = Justify.Center;
            //MoveButtonDown.style.alignItems = Align.FlexEnd;
            //MoveButtonDown.style.alignSelf = Align.FlexEnd;

            
            veMoveButtons.Add(MoveButtonDown);
        }

        for (int i = 0; i < roles.Length; i++)
        {
            if (PrefabUtility.IsPartOfAnyPrefab(roles[i].gameObject)) 
            {
                PrefabUtility.UnpackPrefabInstance(roles[i].gameObject,PrefabUnpackMode.OutermostRoot,InteractionMode.AutomatedAction);
            }
        }
        return ve;
    } //This is where the custom foldouts are created at editor time.  
    #endregion

    #region Field Change Events
    private void IntFieldEdited(ChangeEvent<int> evt, VisualElement target)
    // working
    {
        if (evt.newValue == evt.previousValue || evt.newValue < 0) return;
        int id;
        int.TryParse(evt.currentTarget.ToString().Split('_')[1], out id);
        
        Undo.RecordObject (roles[id], "IntFieldEdited"); // <--- Undo Event
        roles[id].SetManual(evt.newValue);

        int ToDo = evt.newValue - evt.previousValue;

        if (ToDo < 0)
        {
            for (int i = target.childCount - 1; i >= evt.newValue; i--)
            {
                target.RemoveAt(i);
            }
        }
        else
        {
            for (int i = 0; i < ToDo; i++)
            {
                TextField tf = new TextField();
                tf.label = target.childCount.ToString();
                tf.name = $"ManualField_{id}_{target.childCount}";
                tf.RegisterCallback<FocusOutEvent, string>(ManualFieldEdit, tf.name, TrickleDown.NoTrickleDown);
                target.Add(tf);
            }
        }

        TextField[] localtf = new TextField[target.childCount];
        for (int i = 0; i < target.childCount; i++)
        {
            localtf[i] = (TextField)target[i];
            roles[id].SetManualMember(i, localtf[i].text);
        }
    }

    private void ColorEdit(ChangeEvent<Color> evt)
        // Added undo event
    {
        int id;
        int.TryParse(evt.currentTarget.ToString().Split('_')[1], out id);
        VisualElement RoleContainerFoldout = _RootElement.Q<VisualElement>($"VisualElementRC_{id}");

        Undo.RecordObject (roles[id], "ColorEdit"); // <--- Undo Event
        
        roles[id].roleColor = evt.newValue;

        Color32 c32 = roles[id].roleColor;
        StyleColor sc = new StyleColor(c32);
        //RoleContainerFoldout.style.borderColor = sc;
        RoleContainerFoldout.style.borderBottomColor = sc;
        RoleContainerFoldout.style.borderLeftColor = sc;
        RoleContainerFoldout.style.borderRightColor = sc;
        RoleContainerFoldout.style.borderTopColor = sc;
    }

    private void ToggleEdit(ChangeEvent<bool> evt)
        // Added undo event
    {
        int id;
        int.TryParse(evt.currentTarget.ToString().Split('_')[1], out id);

        Toggle IsStaff = RoleContainers[id].Q<Toggle>($"IsStaff_{id}_");
        Toggle IsSupporter = RoleContainers[id].Q<Toggle>($"IsSupporter_{id}_");
        Toggle IsBooster = RoleContainers[id].Q<Toggle>($"IsBooster_{id}_");
        
        Undo.RecordObject (roles[id], "ToggleEdit"); // <--- Undo Event
        
        roles[id].SetStaff(IsStaff.value);
        roles[id].SetisSupporter(IsSupporter.value);
        roles[id].isBooster = IsBooster.value;
        CheckBooters();
    }

    private bool CheckBooters()
    {
        int boosters = 0;
        foreach (var _role in roles)
        {
            if (_role.isBooster) boosters++;
        }

        if (boosters > 1)
        {
            EditorUtility.DisplayDialog("DisBridge Error","You have more than 1 role marked as a Server Booster!\nPlease make sure you only have one role marked as a Server Booster!","OK");
            return true;
        }
        return false;
    }

    private void IconEdit(ChangeEvent<UnityEngine.Object> evt)
        // Added undo event
    {
        int id;
        int.TryParse(evt.currentTarget.ToString().Split('_')[1], out id);

        ObjectField RoleIconField = RoleContainers[id].Q<ObjectField>($"RoleIconField_{id}_");
        Undo.RecordObject (roles[id], "IconEdit"); // <--- Undo Event
        roles[id].roleIcon = (Sprite)RoleIconField.value;
    }

    private void FieldEdit(FocusOutEvent evt, int id) 
        // Added undo event
    {
        currentFoldout = id;
        Foldout RoleContainerFoldout = RoleContainers[id].Q<Foldout>($"RoleContainerFoldout_{id}");
        TextField roleNameField = RoleContainers[id].Q<TextField>($"roleNameField_{id}");
        TextField RoleAltNameField = RoleContainers[id].Q<TextField>($"RoleAltNameField_{id}");

        Undo.RecordObject (roles[id], "FieldEdit"); // <--- Undo Event
        
        if (!string.IsNullOrEmpty(roleNameField.text))
        {
            RoleContainerFoldout.text = roleNameField.text;
            roles[id].roleName = roleNameField.text;
            roles[id].roleAltName = RoleAltNameField.text;
            roles[id].gameObject.name = roleNameField.text;
        }
        else
        {
            RoleContainerFoldout.text = "";
            roles[id].roleName = "";
            roles[id].roleAltName = "";
            roles[id].gameObject.name = "";
        }
    }

    private void IdFieldEdit(FocusOutEvent evt, int id)
    {
        currentFoldout = id;
        Foldout RoleContainerFoldout = RoleContainers[id].Q<Foldout>($"RoleContainerFoldout_{id}");
        TextField roleIdField = RoleContainers[id].Q<TextField>($"roleIdField_{id}");

        Undo.RecordObject(roles[id], "IdFieldEdit"); // <--- Undo Event

        if (!string.IsNullOrWhiteSpace(roleIdField.text))
        {
            roles[id].roleId = roleIdField.text;
        }
        else
        {
            roles[id].roleId = string.Empty;
        }
    }

    private void ManualFieldEdit(FocusOutEvent evt, string id)
        // Added undo event
    {
        int IntId, RoleID;
        
        int.TryParse(id.Split('_')[2], out IntId);

        int.TryParse(id.Split('_')[1], out RoleID);

        currentFoldout = RoleID;
        Undo.RecordObject (roles[RoleID], "ManualFieldEdit"); // <--- Undo Event
        
        roles[RoleID].SetManualMember(IntId, ((TextField)evt.target).text);
    } 
    #endregion

    #region Clicked Functions
    private void MoveRoleUp(int id)
    {
        roles[id].gameObject.transform.SetSiblingIndex(id - 1);
        CreateInspectorGUI();
    }

    private void MoveRoleDown(int id)
    {
        roles[id].gameObject.transform.SetSiblingIndex(id + 1);
        CreateInspectorGUI();
    }

    private void DeleteButton_clicked(int id)
    {
        Debug.Log("User called delete");
        DestroyImmediate(roles[id].gameObject);
        CreateInspectorGUI();
    }

    private void IncButton_clicked()
    {
        GameObject role = (GameObject)PrefabUtility.InstantiatePrefab(RoleContainerPrefab, RolesTransform);
        RoleContainer rc = role.GetComponent<RoleContainer>();
        rc.roleName = "New Role";
        rc.roleColor = Color.white;

        CreateInspectorGUI();
    }

    private void DecButton_clicked()
    {
        DestroyImmediate(roles[roles.Length - 1].gameObject);
        CreateInspectorGUI();
    }

    private void QuestionMarkButton_clicked()
    {
        EditorUtility.DisplayDialog("Disbridge Help?", "With this button you can auto generate rolls from a json file.\n\nThis file is acquired only by having set up the UdonVR bot in your server and running \"/guild-status\" and clicking \"Get Json\"", "OK!");
    }

    private void ParseButton_clicked()
    {
        if (!EditorUtility.DisplayDialog("Override Confirmation","Parsing from a Json file will Overwrite all of your current RoleContainers.\n\nAre you sure you want to Overwrite your current RoleContainers?","Yes, please Delete my RoleContainers","Cancel")) return; 
        string path = EditorUtility.OpenFilePanel("Pick Roles.json", "Downloads", "json");
        
        if (path.Length != 0)
        {
            File.Copy(path, $"{_folderpath}/Runtime/EditorScript/Roles.json", true);
            AssetDatabase.ImportAsset($"{_folderpath}/Runtime/EditorScript/Roles.json");

            if (string.IsNullOrEmpty(path) || !path.Contains(".json"))
            {
                EditorUtility.DisplayDialog("Select Json", "Error: You did not select a file, Or you selected something that was not a .json", "OK");
                return;
            }
            else
            {
                TextAsset ta = (TextAsset)AssetDatabase.LoadAssetAtPath($"{_folderpath}/Runtime/EditorScript/Roles.json", typeof(TextAsset));
                PraseJsonForRoles(ta);
                
            }
        }
        CreateInspectorGUI();
        Repaint();
        EditorUtility.DisplayDialog("Success","Import Has completed!\n\nYou may need to refocus your DisBridge editor for the changes to show up.","OK");
    }

    public void PraseJsonForRoles(TextAsset ta)
    {
        
        DisbridgeKey myKey = JsonConvert.DeserializeObject<DisbridgeKey>(ta.text);

        if (PrefabUtility.IsPartOfAnyPrefab(EditorFunctions.gameObject))
        {
            PrefabUtility.UnpackPrefabInstance(EditorFunctions.gameObject,PrefabUnpackMode.OutermostRoot,InteractionMode.AutomatedAction);
        }
        if (PrefabUtility.IsPartOfAnyPrefab(pm.gameObject))
        {
            PrefabUtility.UnpackPrefabInstance(pm.gameObject,PrefabUnpackMode.OutermostRoot,InteractionMode.AutomatedAction);
        }
        
        while (pm.roles.childCount != 0)
        {
            DestroyImmediate(pm.roles.GetChild(0).gameObject);
        }
        

        pm.key = myKey.key;

        if (string.IsNullOrWhiteSpace(myKey.keyUrl))
            pm.keyUrl = VRC.SDKBase.VRCUrl.Empty;
        else
            pm.keyUrl = new VRC.SDKBase.VRCUrl(myKey.keyUrl);

        foreach (RoleModal _role in myKey.roles)
        {
            GameObject role = (GameObject)PrefabUtility.InstantiatePrefab(RoleContainerPrefab, RolesTransform);
            RoleContainer rc = role.GetComponent<RoleContainer>();
            rc.roleId = _role.roleId;
            rc.roleName = _role.roleName;
            rc.roleColor = _role.GetColor();
            rc.isBooster = _role.isBooster;
        }

    }
    #endregion

}
#endif