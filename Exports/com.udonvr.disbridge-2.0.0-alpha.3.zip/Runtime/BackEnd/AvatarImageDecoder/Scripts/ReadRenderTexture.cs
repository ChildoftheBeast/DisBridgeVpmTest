using System;
using TMPro;
using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.Udon;

public class ReadRenderTexture : UdonSharpBehaviour
{
    /*
     * This script is meant to be used as a One time "Read" for a specific render texture (Since they can't be reused)
     * Once "Primed" by the CheckHirarchyScript, it will decode the retrieved RenderTexture
     */

    [Header("Increasing step size decreases decode time but increases frametimes")]
    [SerializeField] private int stepLength = 200;
    
    //[Header("Call event when finished reading")]
    //[SerializeField] private bool callBackOnFinish = false;
    [SerializeField] private UdonVR.DisBridge.ReadDataManager dataManager;
    //[SerializeField] private string callbackEventName;
    //[SerializeField] private string callbackStringVarName;

    [Header("Render references")]
    [SerializeField] private GameObject renderQuad;
    [SerializeField] private Camera renderCamera;
    [SerializeField] private RenderTexture renderTexture;
    [SerializeField] private Texture2D donorInput;

    [Header("Debugging")]
    [SerializeField] private bool debugLogger;
    [SerializeField] private TextMeshProUGUI loggerText;
    [SerializeField] private bool outputToText;
    [SerializeField] private TextMeshProUGUI outputText;
    
    //internal
    private Color[] colors;
    public string currentOutputString;
    private bool hasRun;
    [HideInInspector] public bool pedestalReady;
    private System.Diagnostics.Stopwatch stopwatch;

    public void OnPostRender()
    {
        if (pedestalReady && !hasRun)
        {
            if (debugLogger)
            {
                stopwatch = new System.Diagnostics.Stopwatch();
                stopwatch.Start();
                Log("ReadRenderTexture: Starting");
            }
            
            if (renderTexture != null)
            {
                //copy the texture over so it can be read
                donorInput.ReadPixels(new Rect(0, 0, renderTexture.width, renderTexture.height), 0, 0);
                donorInput.Apply();
                StartReadPicture(donorInput);
                
                //disable the renderquad to prevent VR users from getting a seizure (disable the camera first so it only renders one frame)
                renderCamera.enabled = false;
                renderQuad.SetActive(false);
                
                if(debugLogger) Log("ReadRenderTexture: Writing Information");
            }
            
            hasRun = true;
        }
    }

    private void Log(string text)
    {
        Debug.Log($"[<color=#00fff7>ReadRenderTexture</color>] |{text}");
        if (loggerText != null) loggerText.text += $" | {text}\n";
        //Comment above line if not using TMPLogger
    }

    private void StartReadPicture(Texture2D picture)
    {
        if(debugLogger)
        {
            Log("Starting Read");
            Log($"Input: {picture.width} x {picture.height} [{picture.format}]");
        }
        
        currentOutputString = "";

        int w = picture.width;
        int h = picture.height;

        colors = new Color[w * h];
        colors = picture.GetPixels();
        int maxBytes = colors.Length * 3;
        
        Array.Reverse(colors);

        Color firstColor = colors[0];
        dataLength = (byte) (firstColor.r * 255) << 16 | (byte) (firstColor.g * 255) << 8 | (byte) (firstColor.b * 255);
        Color secondColor = colors[1];
        version = (byte)(secondColor.r * 255) << 16 | (byte)(secondColor.g * 255) << 8 | (byte)(secondColor.b * 255);
        if (debugLogger) Log("Data length: " + dataLength);
        if (debugLogger) Log("[UdonVR]Version: " + version);
        dataManager.PassVersion(version);
        if (version > 5000)
        {
            ReadDone();
            return;
        }
        if(dataLength > maxBytes)
            dataLength = maxBytes;
        SendCustomEventDelayedFrames(nameof(ReadPictureStep), 2);
    }

    private int index = 2;
    private int byteIndex = 0;
    private int dataLength;
    private int version;

    private byte[] colorBytes = new byte[3];
    private byte[] byteCache = new byte[2];
    private bool lastIndex = true;
    private bool readingKey = true;
    private int readingKeybyte = 0;
    private string key = "";

    public void ReadPictureStep()
    {
        if(debugLogger) Log($"ReadRenderTexture: Reading {index}\n");

        for (int step = 0; step < stepLength; step++)
        {
            Color c = colors[index];

            colorBytes[0] = (byte)(c.r * 255);
            colorBytes[1] = (byte)(c.g * 255);
            colorBytes[2] = (byte)(c.b * 255);

            for (int b = 0; b < 3; b++)
            {
                if (lastIndex)
                {
                    byteCache[0] = colorBytes[b];
                    lastIndex = false;
                }
                else
                {
                    byteCache[1] = colorBytes[b];
                    if (readingKey)
                    {
                        //if(readingKeybyte == 0)
                        //    Debug.Log("[UdonVR][RRT] Start ReadingKey " + key.Length + " [" + key + "]");
                        key += convertBytesToUTF16(byteCache);
                        //Debug.Log("[UdonVR][RRT] " + readingKeybyte + "ReadingKey " + key.Length + " [" + key + "]");
                        if (readingKeybyte == 0)
                        {
                            //Debug.Log("[UdonVR][RRT] " + readingKeybyte + "Byte 0 [" + byteCache[0] + "] " + "Byte 1 [" + byteCache[1] + "]");
                            if (byteCache[0] == 255 && byteCache[1] == 254)
                            {
                                //Debug.Log("[UdonVR][RRT] Setting key to empty");
                                key = string.Empty;
                            }
                        }
                        readingKeybyte++;
                        if (readingKeybyte > 32)
                            readingKey = false;
                    }
                    else
                        currentOutputString += convertBytesToUTF16(byteCache);
                    lastIndex = true;
                }

                byteIndex++;
                if (byteIndex > dataLength)
                {
                    if(debugLogger) Log($"Reached data length: {dataLength}; byteIndex: {byteIndex}");
                    ReadDone();
                    return;
                }
            }

            index++;
        }
        
        SendCustomEventDelayedFrames(nameof(ReadPictureStep), 1);
    }

    private void ReadDone()
    {
        if (debugLogger)
        {
            stopwatch.Stop();
            Log($"Took: {stopwatch.ElapsedMilliseconds} ms");
        }
        
        if(outputToText) outputText.text = currentOutputString;
        
        if(debugLogger) Log("Reading Complete: " + currentOutputString);
        if (dataManager) 
        {
            //if(!string.IsNullOrEmpty(callbackStringVarName.Trim())) dataManager.SetProgramVariable(callbackStringVarName, currentOutputString);
            //dataManager.SendCustomEvent(callbackEventName); 
            //Debug.Log("[UdonVR][RRT] 1ReadDone "+key.Length+" [" + key + "]");
            if (key.Length > 32) { key = key.Substring(1);}
            //Debug.Log("[UdonVR][RRT] 2ReadDone " + key.Length + " [" + key + "]");
            dataManager._ReadDone(key,currentOutputString);
        }

        gameObject.SetActive(false);
    }

    //private string empty = "";
    private string convertBytesToUTF16(byte[] bytes)
    {
        return string.Empty + (char)(bytes[0] | (bytes[1] << 8));
    }
}
