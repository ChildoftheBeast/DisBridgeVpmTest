﻿
using System;
using TMPro;
using UdonSharp;
using UdonVR.DisBridge;
using UdonVR.DisBridge.Plugins;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;
using VRC.Udon;

namespace UdonVR.DisBridge.Plugins
{
    public class Keypad : UdonSharpBehaviour
    {
        public PluginManager manager;
        public DisBridgeWhitelist whitelist;

        [SerializeField] private int _keyCode;
        private int _keyCode_legnth;
        private string _keyCode_user;

        public TextMeshProUGUI view;
        public GameObject placeholderView;

        public bool autoEnter = true;

        [Tooltip("Defines if the local user's code entry should be censored.")]
        public bool showCode = false;

        [Tooltip("Char used to hide the password if `Show Code` is false.")]
        public char hideChar = '•';

        private string hiddenCode = "";
        private string _tmpStr = "";

        private bool unlocked = false;


        [Tooltip("These are OFF by default\nWhen a player's name matches the list, these will TURN ON.")]
        public GameObject[] TargetsDefaultOff;

        [Tooltip("These are ON by default\nWhen a player's name matches the list, these will TURN OFF.")]
        public GameObject[] TargetsDefaultOn;

        private void Start()
        {
            _keyCode_legnth = _keyCode.ToString().Length;
            if (whitelist != null) whitelist.BindKeypad(this);
        }

        public void _UVR_Init()
        {

        }

        private void TryUnlock()
        {
            if (int.Parse(_keyCode_user) == _keyCode)
            {
                unlocked = true;
                view.text = "OPEN";
                UnlockWhitelist();
                if (whitelist != null)
                    whitelist.ForceUnlock(whitelist.name);
            }
            else
            {
                AddChar(-1);
                placeholderView.SetActive(false);
                view.text = "DENIED";
            }
        }

        public void SetUnlocked()
        {
            unlocked = true;
            view.text = "OPEN";
            placeholderView.SetActive(false);
        }

        private void UpdateView()
        {
            hiddenCode = "";
            for (int i = 0; i < _keyCode_user.Length; i++)
            {
                hiddenCode = $"{hiddenCode}{hideChar}";
            }

            if (_keyCode_user != String.Empty)
            {
                view.text = showCode ? _keyCode_user : hiddenCode;
                placeholderView.SetActive(false);
            }
            else
            {
                view.text = "";
                placeholderView.SetActive(true);
            }

            if (autoEnter && _keyCode_user.Length == _keyCode_legnth)
            {
                TryUnlock();
            }
        }

        private void AddChar(int _num)
        {
            if (unlocked) return;
            _keyCode_user = _num == -1 ? "" : $"{_keyCode_user}{_num}";
            UpdateView();
        }

        private void UnlockWhitelist()
        {
            foreach (GameObject _obj in TargetsDefaultOn)
            {
                if (_obj != null)
                    _obj.SetActive(false);
            }

            foreach (GameObject _obj in TargetsDefaultOff)
            {
                if (_obj != null)
                    _obj.SetActive(true);
            }
        }

        #region Buttons

        public void _But_0()
        {
            AddChar(0);
        }

        public void _But_1()
        {
            AddChar(1);
        }

        public void _But_2()
        {
            AddChar(2);
        }

        public void _But_3()
        {
            AddChar(3);
        }

        public void _But_4()
        {
            AddChar(4);
        }

        public void _But_5()
        {
            AddChar(5);
        }

        public void _But_6()
        {
            AddChar(6);
        }

        public void _But_7()
        {
            AddChar(7);
        }

        public void _But_8()
        {
            AddChar(8);
        }

        public void _But_9()
        {
            AddChar(9);
        }

        public void _But_Clear()
        {
            AddChar(-1);
        }

        public void _But_Enter()
        {
            TryUnlock();
        }

        #endregion
    }
}