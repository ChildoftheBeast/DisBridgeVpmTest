﻿//Copyright (c) 2021 UdonVR LLC

using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

namespace UdonVR.DisBridge.Plugins
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class DisBridgeWhitelist : UdonSharpBehaviour
    {
        [Tooltip("Leave this blank if you don't want it to unlock automatically.")]
        [SerializeField] private PluginManager manager;
        [Tooltip("If this is True, it will allow All Staff to use the button.")]
        [SerializeField] private bool checkStaff = false;
        [Tooltip("If this is True, it will allow All Supporters to use the button.")]
        [SerializeField] private bool checkSupporters = false;
        [Tooltip("Adds the role specified to the unlock check.")]
        [SerializeField] private int[] checkRoles;

        [Tooltip("These are OFF by default\nWhen a player's name matches the list, these will TURN ON.")]
        public GameObject[] TargetsDefaultOff;

        [Tooltip("These are ON by default\nWhen a player's name matches the list, these will TURN OFF.")]
        public GameObject[] TargetsDefaultOn;

        public Keypad[] keypads;

        private void Start()
        {
            manager.AddPlugin(gameObject);
            foreach (var _obj in TargetsDefaultOn)
            {
                _obj.SetActive(true);
            }
            foreach (var _obj in TargetsDefaultOff)
            {
                _obj.SetActive(false);
            }
        }

        public void _UVR_Init()
        {
            if (UnlockCheck()) UnlockWhitelist();
        }

        public void ForceUnlock(string _code)
        {
            if (_code == gameObject.name)
                UnlockWhitelist();
        }

        public void BindKeypad(Keypad keypad)
        {
            keypads = DisBridgeFunctions.AddToArray(keypad, keypads);
        }

        private bool UnlockCheck()
        {
            if (checkStaff && manager.IsStaff(Networking.LocalPlayer))
            {
                return true;
            }
            if (checkSupporters && manager.IsSupporter(Networking.LocalPlayer))
            {
                return true;
            }
            if (checkRoles == null || checkRoles.Length <= 0) return false;
            for (int i = 0; i < checkRoles.LongLength; i++)
            {
                if (manager.IsMember(checkRoles[i],Networking.LocalPlayer))
                {
                    return true;
                }
            }
            return false;
        }
        
        private void UnlockWhitelist()
        {
            if (keypads != null && keypads.Length != 0)
            {
                foreach (var _keypad in keypads)
                {
                    _keypad.SetUnlocked();
                }
            }
            foreach (GameObject _obj in TargetsDefaultOn)
            {
                if (_obj != null)
                    _obj.SetActive(false);
            }
            foreach (GameObject _obj in TargetsDefaultOff)
            {
                if (_obj != null)
                    _obj.SetActive(true);
            }
        }
    }
}
