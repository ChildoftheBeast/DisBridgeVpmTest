by default, there are 30 tags in the pool of usable tags.
<br>If you plan on needing more than 30 tags, it is recommended to add more tags to the pool.
<br>The prefab supports creating more tags if it needs to, but this is un performant and not recommended. It should be used a a safety net and not relied on.