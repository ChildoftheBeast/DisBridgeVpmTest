﻿//Copyright (c) 2021 UdonVR LLC

using System;
using UnityEditor;
using UnityEngine;

namespace UdonVR.DisBridge
{
    public class CreatePrefabs
    {
        private const int Menu = 49;
        private const string filePath = "Packages/com.udonvr.disbridge/Runtime/Prefabs/";

        [MenuItem("GameObject/UdonVR/DisBridge/Plugins/Toggles/Local", false, Menu)]
        static void CreateLocalToggle(MenuCommand _cmd)
        {
            Debug.Log("[UdonVR][DisBridge] Creating Local_DisbridgeToggle");
            CreateDisBridgePrefab("Plugins/Local_DisbridgeToggle.prefab", _cmd);
        }

        [MenuItem("GameObject/UdonVR/DisBridge/Plugins/Toggles/Global", false, Menu)]
        static void CreateGlobalToggle(MenuCommand _cmd)
        {
            Debug.Log("[UdonVR][DisBridge] Creating Global_DisbridgeToggle");
            CreateDisBridgePrefab("Plugins/Global_DisbridgeToggle.prefab", _cmd);
        }


        [MenuItem("GameObject/UdonVR/DisBridge/Parts/PluginManager", false, Menu)]
        static void CreatePluginManager(MenuCommand _cmd)
        {
            Debug.Log("[UdonVR][DisBridge] Creating RoleContainer");
            CreateDisBridgePrefab("Parts/PluginManager.prefab", _cmd);
        }

        [MenuItem("GameObject/UdonVR/DisBridge/Parts/RoleContainer", false, Menu)]
        static void CreateRoleContainer(MenuCommand _cmd)
        {
            Debug.Log("[UdonVR][DisBridge] Creating RoleContainer");
            CreateDisBridgePrefab("Parts/RoleContainer.prefab", _cmd);
        }

        [MenuItem("GameObject/UdonVR/DisBridge/DisBridge", false, Menu)]
        static void CreateDisBridge(MenuCommand _cmd)
        {
            Debug.Log("[UdonVR][DisBridge] Creating RoleContainer");
            CreateDisBridgePrefab("DisBridge.prefab", _cmd);
        }

        [MenuItem("GameObject/UdonVR/DisBridge/Plugins/RoleBoard", false, Menu)]
        static void CreateRoleBoard(MenuCommand _cmd)
        {
            Debug.Log("[UdonVR][DisBridge] Creating RoleBoard");
            CreateDisBridgePrefab("Plugins/RoleBoard.prefab", _cmd);
        }

        [MenuItem("GameObject/UdonVR/DisBridge/Plugins/RoleTags", false, Menu)]
        static void CreateRoleTags(MenuCommand _cmd)
        {
            Debug.Log("[UdonVR][DisBridge] Creating RoleTags");
            CreateDisBridgePrefab("Plugins/RoleTags.prefab", _cmd);
        }

        [MenuItem("GameObject/UdonVR/DisBridge/Plugins/Debugger", false, Menu)]
        static void CreateDisBridgeDebugger(MenuCommand _cmd)
        {
            Debug.Log("[UdonVR][DisBridge] Creating DisBridgeDebugger");
            CreateDisBridgePrefab("Plugins/DisBridgeDebugger.prefab", _cmd);
        }



        private static void CreateDisBridgePrefab(string filename, MenuCommand _cmd, bool _unPack = false)
        {
            //Debug.Log("[UdonVR] Trying to load Prefab from file [Assets/_UdonVR/Tools/Utility/Prefabs/" + filename + "]");
            var loadedObject = AssetDatabase.LoadAssetAtPath(filePath + filename, typeof(UnityEngine.Object));
            if (loadedObject == null)
            {
                Debug.LogError("[UdonVR] Failed to find File, did you move the _UdonVR folder? File[" + filename + "]");
                return;
            }

            CreateObj(loadedObject, _cmd, _unPack);
        }

        private static void CreatePrefabFromFile(string filename, MenuCommand _cmd, bool _unPack = false)
        {
            //Debug.Log("[UdonVR] Trying to load Prefab from file [" + filename + "]");
            var loadedObject = AssetDatabase.LoadAssetAtPath(filename, typeof(UnityEngine.Object));
            if (loadedObject == null)
            {
                Debug.LogError("[UdonVR] Failed to find File at [" + filename + "]?");
                return;
            }

            CreateObj(loadedObject, _cmd, _unPack);
        }

        private static void CreateObj(UnityEngine.Object _loadedObject, MenuCommand _cmd, bool _unPack)
        {
            GameObject _obj = (GameObject)PrefabUtility.InstantiatePrefab(_loadedObject);
            GameObject _target = (_cmd.context as GameObject);
            Undo.RegisterCreatedObjectUndo(_obj, "[UdonVR] Created Prefab");
            if (_target != null)
            {
                _obj.transform.SetParent(_target.transform);
                _obj.transform.SetPositionAndRotation(_target.transform.position, _target.transform.rotation);
                _obj.layer = _target.layer;
            }

            _obj.transform.SetAsLastSibling();
            Selection.activeGameObject = _obj;
            if (_unPack)
            {
                PrefabUtility.UnpackPrefabInstance(_obj.gameObject, PrefabUnpackMode.Completely,
                    InteractionMode.AutomatedAction);
            }
        }
    }
}
